from tkinter import *
from tkinter.font import Font

def clear_receipt():
    global total, receipt
    total = 0
    receipt = ''
    total_var.set(f'${total}')
    receipt_var.set(f'{receipt}')

def add_item(amount, text):
    global total, receipt

    total += amount
    receipt += f'\n{text} - ${amount}'

    total_var.set(f'${total:.2f}')
    receipt_var.set(receipt)

def coffee():
    pass

def tea():
    pass

def drink():
    pass

def sandwich():
    pass

def sweet():
    pass

def bakery():
    pass




#MAIN
#Holding frames
#########
global total, receipt
total = 0
receipt = ''

root = Tk()
mainframe = Frame(root)

#Widgets
#########

cafe_small = Font(family="House Home", size=40)
cafe_large = Font(family="House Home", size=80)

##coffee_photo = 
##tea_photo = 
##drink_photo = 
##sandwich_photo = 
##sweet_photo = 
##bakery_photo = 

coffee_button = Button(mainframe, command=coffee)
tea_button = Button(mainframe, command=tea)
drink_button = Button(mainframe, command=drink)
sandwich_button = Button(mainframe, command=sandwich)
sweet_button = Button(mainframe, command=sweet)
bakery_button = Button(mainframe, command=bakery)

clear_button = Button(mainframe, text='clear', font=cafe_small, command=clear_receipt)

title_label = Label(mainframe, text="CAFE", font=cafe_small)

total_var = StringVar()
total_var.set(f'${total:.2f}')
total_label = Label(mainframe, textvariable=total_var, font=cafe_large)

receipt_var = StringVar()
receipt_label = Label(mainframe, textvariable=receipt_var, font=cafe_small, justify=LEFT)

#GRID THE WIDGETS
###########
mainframe.grid(padx=50, pady=50)

title_label.grid(row=1, column=1, sticky=W)
total_label.grid(row=1, column=2, columnspan=2, sticky=E)

coffee_button.grid(row=2, column=1)
tea_button.grid(row=2, column=2)
drink_button.grid(row=2, column=3)
sandwich_button.grid(row=3, column=1)
sweet_button.grid(row=3, column=2)
bakery_button.grid(row=3, column=3)
clear_button.grid(row=4, column=1, columnspan=3, sticky=EW)

receipt_label.grid(row=5, column=1, columnspan=3, sticky=W)


root.mainloop()

