from tkinter import *
from tkinter.font import Font

def change_weather(ignore):
    global weather_pictures, weather_colours
    
    


#MAIN
#Holding frames
#########
root = Tk()
mainframe = Frame(root)

#Widgets
#########
weather_font = Font(family="Weather in October", size=50)

sun_photo = PhotoImage(file="sunny.png")
suncloud_photo = PhotoImage(file="suncloud.png")
cloud_photo = PhotoImage(file="cloudy.png")
rain_photo = PhotoImage(file="rainy.png")

global weather_pictures, weather_colours
weather_colours = [None, '#6D6D6D', '#83D4ED', '#C4E1E9', '#FBD462']
weather_pictures = [None, rain_photo, cloud_photo, suncloud_photo, sun_photo]

weather_image_label = Label(mainframe, image=None)

weather_var = IntVar()
weather_var.set(0)
weather_scale = Scale(mainframe, from_=1, to=4, variable=weather_var, \
                      label="weather", width=30, length=100, \
                      showvalue=False, orient=HORIZONTAL, font=weather_font, \
                      troughcolor = '#111111', command=change_weather)


#GRID THE WIDGETS
###########
mainframe.grid(padx=100, pady=50)

weather_image_label.grid(row=1, column=1, pady=20)
weather_scale.grid(row=2, column=1, ipadx=50)



root.mainloop()

