from tkinter import *
from tkinter.font import Font

def updatePlan():

    pass


    
root = Tk()
root.config(bg="#1DB954")
mainframe = Frame(root)

traffoFontSmall = Font(family="Moonbeam", size=30)
traffoFontLarge = Font(family="Moonbeam", size=60)

planInformationList = ['INDIVIDUAL\n$9.99 CAD/mnth\n1 account', \
                       'DUO\n$12.99 CAD/mnth\n2 accounts', \
                       'FAMILY\n$14.99 CAD/mnth\n6 accounts', \
                       'STUDENT\n$4.99 CAD/mnth\n1 account']

planChoiceVar = IntVar()
individualRadio = Radiobutton(mainframe, text="individiual", \
                              variable=planChoiceVar, value=0, \
                              font=traffoFontSmall, command=updatePlan)

planChoiceVar.set(0)


infoVar = StringVar()
infoVar.set(planInformationList[0])
infoLabel = Label(mainframe, textvariable=infoVar, font=traffoFontLarge)



#GRID WIDGETS
mainframe.grid(padx=50, pady=50)

individualRadio.grid(row=1, column=1, padx=10)

root.mainloop()
