from tkinter import *
from tkinter import messagebox
from tkinter.font import Font


def check_login():
    global attempts_left
    

    #this function should be called if login not successful
    check_freeze_account()
        

def check_freeze_account():
    global attempts_left
    
        

#CREATE WIDGETS
root = Tk()
mainframe = Frame(root)

checkbook_big = Font(family='Checkbook', size=60)
checkbook_small = Font(family='Checkbook', size=20)

global attempts_left
attempts_left = 3

username_label = Label(mainframe, text="USERNAME:", font=checkbook_small)
username_var = StringVar()
username_entry = Entry(mainframe, textvariable=username_var, width=10, font=checkbook_big)

password_label = Label(mainframe, text="PASSWORD:", font=checkbook_small)
password_var = StringVar()
password_entry = Entry(mainframe, show="*", textvariable=password_var, width=10, font=checkbook_big)

login_button = Button(mainframe, text="LOGIN", command=check_login, font=checkbook_big)



#GRID WIDGETS
mainframe.grid(row=1, column=1, padx=50, pady=50)

username_label.grid(row=1, column=1, sticky=E, padx=20, pady=20)
username_entry.grid(row=1, column=2, padx=20, pady=20)

password_label.grid(row=2, column=1, sticky=E, padx=20, pady=20)
password_entry.grid(row=2, column=2, padx=20, pady=20)

login_button.grid(row=3, column=2, padx=20, sticky=EW)


